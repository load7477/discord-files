import requests, math

def get_zip_file_size(url):
    response = requests.head(url)
    if 'Content-Length' in response.headers:
        file_size = int(response.headers['Content-Length'])
        return file_size
    else:
        return None

def format_size(size):
    if size < 1024:
        return f"{size} 바이트"
    elif size < 1024 * 1024:
        kb_size = math.ceil(size / 1024)
        return f"{kb_size} KB"
    else:
        mb_size = math.ceil(size / (1024 * 1024))
        return f"{mb_size} MB"

def getfilesize(url):
    file_size = get_zip_file_size(url)
    if file_size is not None:
        size = format_size(file_size)
        print(size)
        return size
    else:
        return 0
