import discord
from discord.ext import commands
from utils.db import getp

intents = discord.Intents.all()
client = discord.Bot(intents=intents)


class point(discord.ui.Modal):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(
            discord.ui.InputText(label="USER ID",placeholder=""),
            *args,
            **kwargs,
        )

    async def callback(self, interaction: discord.Interaction):
        try:
            a = getp(interaction.user.id)
            print(self.children[0].value, '', len(self.children[0].value))
            if len(self.children[0].value) == '19' or len(self.children[0].value) == 19 or len(self.children[0].value) == 18 or len(self.children[0].value) == 17: await interaction.response.send_message(f"# <@{self.children[0].value}> 님의 포인트는 {a[0]['point']} P 입니다.", ephemeral=True)
            else: await interaction.response.send_message(f"# ** Injection이 감지되었습니다 ** \n> __USER ID : {interaction.user.id}__\n> __USER NAME : {interaction.user.name}__\n> __ MESSAGE : {self.children[0].value} __", ephemeral=False)
        except Exception as e: await interaction.response.send_message(f"# 등록된 유저가 없거나 에러가 발생하였습니다. \n# ERROR : {e}", ephemeral=True)