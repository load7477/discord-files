from tkinter.tix import CheckList
import discord
from discord.ui import InputText, Modal
from discord.commands import Option
from discord.ui import Button, View, Select
import asyncio
import utils.db as point
from utils.modal import point as modals
from utils.get import getfilesize

intents = discord.Intents.all()
client = discord.Bot(intents=intents)

@client.event
async def on_ready():
    print("봇이 작동합니다.")

@client.event
async def on_message(message):
    if message.content == "!rank":
        userinfo = point.isrank()
        co, b, ranking, msg = 0, userinfo[1], [], []
        for i in userinfo:
            ranking.append(i[0][1])
        a = sorted(ranking, reverse=True)

        for i in userinfo:
            await message.channel.send("",embed=discord.Embed(color=0x5865F2, title="Ranking System", description=f'{co+1}등 : {a[co]} 개 ( 닉네임 미공개 )'))


            
    msg="메시지 미첨부"
    if message.attachments:
        i = message.attachments
        try:
            userinfo = point.getuserinfo(message.author.id)
            point.addcount(userinfo, message.author.id)
        except:
            pass

        if 'png' in i or 'jpg' in i or 'jpeg' in i or 'webp' in i:
            pass
        else:
            if message.content == "": msg="메시지 미첨부" 
            else: msg=message.content
            filesize = getfilesize(i[0].url)
            await message.author.send(f"""1포인트가 추가되었습니다\n* 파일이름 : {i[0].filename}\n* 파일 링크 : {i[0].url}\n* 파일 사이즈 : {filesize}\n\n메시지 확인하기 * - https://ptb.discord.com/channels/{message.id}/{message.channel.id}/{message.author.id}\n\n----------------------------------------""")
            await client.get_channel(1115272112714829908).send(f"""파일이 올라왔습니다.\n* 배포자 태그 : {message.author}\n* 메시지 : {msg}\n* 파일이름 : {i[0].filename}\n* 파일 링크 : {i[0].url}\n* 파일 사이즈 : {filesize}\n\n메시지 확인하기 * - https://ptb.discord.com/channels/{message.id}/{message.channel.id}/{message.author.id}\n\n----------------------------------------""")

@client.listen("on_interaction")
async def on_interaction(interaction):
    custom_id = interaction.data["custom_id"]
    if not interaction.is_component(): return
    if not interaction.data["component_type"] == 2: return
    if custom_id == 'point':
        modal = modals(title="Temporary Title")
        modal.title = "# Point System"
        await interaction.response.send_modal(modal)

client.run("")